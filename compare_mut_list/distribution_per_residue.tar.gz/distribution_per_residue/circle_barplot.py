import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def prep_dataframe(p):
    df = pd.read_csv(p)
    
    wt = list(df['WT residue'])
    pos = list(df['Position'])
    mut = list(df['Mutated residue'])
    
    o = []
    for i in range(len(wt)):
        orginal = wt[i]+str(pos[i])
        o.append(orginal)
    
    d = {"WT": wt, "Position": pos, "MUT": mut, "WT_pos": o}
    
    df_list = pd.DataFrame(data=d)
    df_list = df_list.dropna()
    df_list = df_list.reset_index(drop=True)
    df_list = df_list.sort_values(by='Position')#p53 sites to care about
    
    df_DBD = df_list.loc[187:1316].reset_index(drop=True)
    
    return df_DBD
    
df_DBD = prep_dataframe("metatable.csv")

def x_y(df_DBD):
    
    a = df_DBD['WT_pos'].value_counts()[df_DBD['WT_pos'].unique()]
    y = list(a)    
    wt_list = list(df_DBD['WT_pos'])
    x = sorted(set(wt_list), key=wt_list.index)   
    
    return x,y 

x,y = x_y(df_DBD)

def circle_barplot(x,y):

    len_y = len(y)
    count_y = np.array(y)
    
    theta=np.arange(0,2*np.pi,2*np.pi/len_y)
    width = (2*np.pi)/len_y *0.9
    bottom = 25
    
    fig = plt.figure(figsize=(13,13))
    ax = fig.add_axes([0.1, 0.1, 0.75, 0.75], polar=True)
    bars = ax.bar(theta, count_y, width=width, bottom=bottom, color='darkslategrey', alpha=0.8)
    
    plt.axis('off')
    labelPadding = 1
    
    for bar, theta, height, label in zip(bars, theta, y, x):

        # Labels are rotated. Rotation must be specified in degrees :(
        rotation = np.rad2deg(theta)
    
        # Flip some labels upside down
        alignment = ""
        if theta >= np.pi/2 and theta < 3*np.pi/2:
            alignment = "right"
            rotation = rotation + 180
        else: 
            alignment = "left"
    
        # Finally add the labels
        ax.text(
            x=theta, 
            y=bottom+bar.get_height()+labelPadding, 
            s=label, 
            ha=alignment, 
            va='center', 
            rotation=rotation, 
            rotation_mode="anchor") 
    
    plt.savefig("circular_barplot.pdf") 
    plt.show()

    return

circle_barplot(x,y)
