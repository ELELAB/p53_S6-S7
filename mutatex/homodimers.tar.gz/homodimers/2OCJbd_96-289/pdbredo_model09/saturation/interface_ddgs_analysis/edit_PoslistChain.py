input_files = ["cancermuts_list.txt", "gnomAD_low_freq.txt", "thermomutdb_single_DBD_unique.txt", "somatic_p53DB_list.txt", "germline_p53DBD_list.txt", "germline_from_literature.txt"]

for file in input_files: 
    with open (file, 'r') as mut_list:
        out_file = open("new_" + file, "w")
        for row in mut_list:
            string_list = list(row)
            string_list[1] = "B"
            replaced = "".join(string_list)
            print(replaced.rstrip("\n"), file=out_file)
        out_file.close()
