awk ' $2 < -0.8 ' summary.txt  > stabilizing.txt
awk ' $2 >= -0.8 && $2 <= 0.8 ' summary.txt > neutral.txt
awk ' $2 > 0.8 ' summary.txt > destabilizing.txt
