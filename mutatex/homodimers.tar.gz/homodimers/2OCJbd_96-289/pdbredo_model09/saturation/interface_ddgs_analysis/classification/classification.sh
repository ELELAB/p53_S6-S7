awk ' $2 < -1.2 ' ../summary_2.txt  > stabilizing_cancermuts.txt #cancermuts mutations
awk ' $2 < -1.2 ' ../summary_3.txt  > stabilizing_somatic.txt
awk ' $2 < -1.2 ' ../summary_4.txt  > stabilizing_germline.txt
awk ' $2 < -1.2 ' ../summary_5.txt  > stabilizing_germline_lit.txt 
awk ' $2 >=-1.2 && $2 <=1.2 ' ../summary_2.txt > neutral_cancermuts.txt 
awk ' $2 >=-1.2 && $2 <=1.2 ' ../summary_3.txt > neutral_somatic.txt
awk ' $2 >=-1.2 && $2 <=1.2 ' ../summary_4.txt > neutral_germline.txt
awk ' $2 >=-1.2 && $2 <=1.2 ' ../summary_5.txt > neutral_germline_lit.txt
awk ' $2 >1.2 && $2 <=3 ' ../summary_2.txt > destabilizing_cancermuts.txt
awk ' $2 >1.2 && $2 <=3 ' ../summary_3.txt > destabilizing_somatic.txt
awk ' $2 >1.2 && $2 <=3 ' ../summary_4.txt > destabilizing_germline.txt
awk ' $2 >1.2 && $2 <=3 ' ../summary_5.txt > destabilizing_germline_lit.txt
awk ' $2 >3 ' ../summary_2.txt > highly_destabilizing_cancermuts.txt
awk ' $2 >3 ' ../summary_3.txt > highly_destabilizing_somatic.txt
awk ' $2 >3 ' ../summary_4.txt > highly_destabilizing_germline.txt
awk ' $2 >3 ' ../summary_5.txt > highly_destabilizing_germline_lit.txt

