sed -e 's#\(.\{1\}\)\(.*\)#\1B\2#g' selected_neutral_list.txt > selected_neutral_list_chain.txt 

ddg2summary -p ../2OCJbd_noHOH_model0_checked.pdb -d ../final_averages -l ../mutation_list.txt -L selected_neutral_list_chain.txt  
