model=$1
source=$2
pdb=$3
#mutlist_1=thermomutdb_single_DBD_unique.txt
#mutlist_2=cancermuts_list.txt
#mutlist_3=somatic_p53DB_list.txt
#mutlist_4=germline_p53DBD_list.txt
#mutlist_5=germline_from_literature.txt
#mutlist_6=gnomAD_low_freq.txt
. /usr/local/envs/mutatex/bin/activate
#have the list of mutations from thermomutDB and cancermuts
ln -s ../../../../../../mutatex/homodimers/$model/$source/saturation/results/interface_ddgs/final_averages/B-D ./final_averages
ln -s ../../../../../../mutatex/homodimers/$model/$source/saturation/$pdb
ln -s ../../../../../../mutatex/homodimers/$model/$source/saturation/mutation_list.txt


#declare -a StringArray1=("new_thermomutdb_single_DBD_unique.txt" "new_cancermuts_list.txt" "new_somatic_p53DB_list.txt" "new_germline_p53DBD_list.txt" "new_gnomAD_low_freq.txt" "new_germline_from_literature.txt")

#i=0
#for list in ${StringArray1[@]}; do
#	i=$((i+1))	
#	ddg2summary -p $pdb -d final_averages -l mutation_list.txt -L $list
#	mv summary.txt summary_$i.txt
#done

#ddg2excel -p $pdb -d final_averages/ -q poslist.txt -l mutation_list.txt -b labels.csv
#ddg2density -p $pdb -d final_averages/ -q poslist.txt -l mutation_list.txt 
#ddg2heatmap -p $pdb -d final_averages/ -q poslist.txt -l mutation_list.txt -x 5 -c viridis -s 40 -f 8 -b labels.csv
#ddg2distribution -p $pdb -d final_averages/ -q poslist.txt -l  mutation_list.txt -T scatter -u 20 -b labels.csv
#ddg2logo -p $pdb -d final_averages/ -q poslist.txt -l mutation_list.txt -T 1.2 -x 10 -s 40 -f 8 -b labels.csv

