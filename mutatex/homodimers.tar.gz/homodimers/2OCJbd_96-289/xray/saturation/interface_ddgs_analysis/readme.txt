#analyses of mutatex scan

### REQUIREMENTS

# Mutation lists of interest
- thermomutdb_single_DBD_unique.txt
- cancermuts_list.txt
- somatic_p53DB_list.txt
- germline_p53DBD_list.txt
- gnomAD_low_freq.txt
- germline_from_literature.txt

# Scripts
edit_PoslistChain.py
AAcode_3L_to_1L.sh

### CHECK MUTATION LISTS OF INTEREST
#edit the script correcting the p53 chain letter according to the available .pdb
#the scripts will generate the same files with the changed chain
python3 edit_PoslistChain.py

### p53 POSLIST
# select residues at the interface (within 6A from the other chain) and create a temporary poslist (wrong AA letter code)
cat 2OCJbd_interface.pdb | awk '{print $4 $5 $6}' | uniq > poslist_tmp.txt
# poslist from 3 letter code to 1 letter code
bash AAcode_3L_to_1L.sh poslist_tmp.txt > poslist.txt
rm poslist_tmp.txt

### VIRTUAL ENVIRONMENT activation
. /usr/local/envs/mutatex/bin/activate

### LABELS 
pdb2labels -p 2OCJbd_noHOH_model0_checked.pdb  -o labels_p53.csv
#edit labels_p53.csv with excel (remove chain)

### RUN ANALYSES
./run_mutatex_analysis.sh $model $source $pdb

#example
./run_mutatex_analysis.sh "2OCJbd_96-289" "xray" "2OCJbd_noHOH_model0_checked.pdb"
