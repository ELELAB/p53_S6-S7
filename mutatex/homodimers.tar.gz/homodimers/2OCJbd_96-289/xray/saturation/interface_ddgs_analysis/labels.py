import numpy as np
import pandas as pd

labelsDF = pd.read_csv("labels_p53.csv")
sep = "_"
labelsDF['Label'] = labelsDF['Residue_name'].str.split(sep, expand=True)[0]
labelsDF['Label'] = labelsDF['Label'].str[0] + labelsDF['Label'].str[2:]
labelsDF.to_csv('labels.csv', index=False)
