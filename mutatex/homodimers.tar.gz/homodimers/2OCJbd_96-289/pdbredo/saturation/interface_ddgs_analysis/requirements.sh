### MUTATION LISTS
cp /data/user/ludovica/mutatex_analysis/thermomutdb_single_DBD_unique.txt .
cp /data/user/ludovica/mutatex_analysis/cancermuts_list.txt .
cp /data/user/ludovica/mutatex_analysis/somatic_p53DB_list.txt .
cp /data/user/ludovica/mutatex_analysis/germline_p53DBD_list.txt .
cp /data/user/ludovica/mutatex_analysis/gnomAD_low_freq.txt .
cp /data/user/ludovica/mutatex_analysis/germline_from_literature.txt .

### SCRIPTS
cp /data/user/ludovica/mutatex_analysis/AAcode_3L_to_1L.sh .
cp /data/user/ludovica/mutatex_analysis/edit_PoslistChain.py .
cp /data/user/ludovica/mutatex_analysis/run_mutatex_analysis.sh .
cp /data/user/ludovica/SCRIPTS/mutatex/labels.py .

### README
cp /data/user/ludovica/mutatex_analysis/readme.txt .
