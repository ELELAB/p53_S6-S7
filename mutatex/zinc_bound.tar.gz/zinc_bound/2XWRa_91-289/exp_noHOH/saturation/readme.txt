#analyses of mutatex scan

#Requirements
#mutation lists of interest
- thermomutdb_single_DBD_unique.txt
-  cancermuts_list.txt

./run_mutatex_analysis.sh $variant $source $pdb

#example
variant=2XWRa_91-289
source=exp_noHOH
pdb=2XWRa_model0_checked.pdb

