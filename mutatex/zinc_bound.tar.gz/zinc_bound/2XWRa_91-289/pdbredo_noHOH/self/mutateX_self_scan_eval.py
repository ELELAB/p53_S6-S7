#quick and dirty python script for self mutation collection

#params:
    
    #MUTATEX self mut
    #threshold = -1.2, 1,2

#import relevant packages

from glob import glob
import pandas as pd
import os

#create a list of models
path = os.getcwd()
dir_list = glob('./mutation_ddgs/*')
dir_list = [i.split('/')[-1] for i in dir_list]

#change directories
os.chdir('mutation_ddgs')
path1 = os.getcwd()

#create empty list for list of lists    
l = []

#start loop for building list of lists
for i in range(len(dir_list)):
        
    os.chdir(dir_list[i])
    
    #open the file exported by mutateX            
    df = pd.read_csv("selfmutation_energies.dat", sep='\t')
    df = df['# avg']
    
    #change format
    for j in range(len(df)):
        Line = df[j].split(' ') 
        Line = list(filter(None, Line))
        
        #find values above threshold
        if float(Line[1]) >=1.2 or float(Line[1]) <= -1.2 or float(Line[3]) >=1.2 or float(Line[3]) <= -1.2 or float(Line[4]) >=1.2 or float(Line[4]) <= -1.2:  
            
            #add information on model
            Line.insert(0, str(dir_list[i]))
            #collect in list of lists
            l.append(Line)
            
        #return to previous path
        os.chdir(path1)

#create pandas dataframe
column_names = ['model', 'position', 'avg', 'std', 'min', 'max']        
df1 = pd.DataFrame(l, columns=column_names)

#export as csv in the parent folder 
os.chdir(path)
df1.to_csv('selfmutation_energy_above_threshold.csv')
