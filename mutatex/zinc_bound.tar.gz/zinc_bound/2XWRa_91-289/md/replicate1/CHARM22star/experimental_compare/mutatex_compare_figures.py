import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

def time_figure(time):
    #only allow comparison of three runs to have identical colors that does
    #not come from a palette
    
    hours = [] 
    for i in range(len(time)):
    #hours/frames
        per_hour = time.iloc[i][1]/time.iloc[i][0]
        hours.append(per_hour)
        
    time["hour/frame"] = hours
                          
    fig = plt.figure(figsize=(6,6))
    sns.set_style("white")
    sns.barplot(x='frames', y='hour/frame', data=time, palette =['black', 'darkmagenta', 'grey'])
    fig.savefig('timing_barchart.pdf')
    
    return fig
#import the csv
ddG = pd.read_csv('ddG_compare.csv')

#calculate the peason correlations
correlations = ddG.corr(method='pearson')
#extract the correlations with experimental ddG
corr = correlations.iloc[0]

#extract the column names as parameters
parameter_list = list(ddG.columns)

def correlationplot_collected():
    #define x and y fot plotting
    x = ddG['ddG']
    #set figure size
    plt.figure(figsize=(8,8))
    #create basic scatterplot with error bars
    
    #1 parameter_list[9] = 'ddG_1frame'
    plt.errorbar(x, ddG[parameter_list[9]], yerr=ddG[parameter_list[9+1]], xerr=ddG['std'], fmt="o", color='black', alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[9]], 1)
    plt.plot(x, corr[parameter_list[9]]*x+b, color = "black", alpha=0.9)
    
    
    #25 parameter_list[3] = 'ddG_25frames'
    plt.errorbar(x, ddG[parameter_list[3]], yerr=ddG[parameter_list[3+1]], xerr=ddG['std'], fmt="o", color='orange', alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[3]], 1)
    plt.plot(x, corr[parameter_list[3]]*x+b, color = "orange", alpha=0.9)
    
    #50 parameter_list[5] = 'ddG_50frames'
    plt.errorbar(x, ddG[parameter_list[5]], yerr=ddG[parameter_list[5+1]], xerr=ddG['std'], fmt="o", color='royalblue', alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[5]], 1)
    plt.plot(x, corr[parameter_list[5]]*x+b, color = "royalblue", alpha=0.9)
    
    #100 parameter_list[7]='ddG_100frames'
    plt.errorbar(x, ddG[parameter_list[7]], yerr=ddG[parameter_list[7+1]], xerr=ddG['std'], fmt="o", color='blueviolet', alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[7]], 1)
    plt.plot(x, corr[parameter_list[7]]*x+b, color = "blueviolet", alpha=0.9)
    
    #xray parameter_list[11] = 'ddG_Xray'
    plt.errorbar(x, ddG[parameter_list[11]], yerr=ddG[parameter_list[11+1]], xerr=ddG['std'], fmt="o", color='magenta', alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[11]], 1)
    plt.plot(x, corr[parameter_list[11]]*x+b, color = "magenta", alpha=0.9)
    
    
    plt.legend(['1 Frame', '25 frames','50 frames','100 Frames', 'X-ray'], loc='upper center', frameon=False, bbox_to_anchor=(0.5, -0.1), ncol=5)
    
    plt.text(-2,-6.2, f"Coef. = {round(corr[parameter_list[9]],3)}      Coef. = {round(corr[parameter_list[3]],3)}         Coef. = {round(corr[parameter_list[5]],3)}             Coef. = {round(corr[parameter_list[7]],3)}       Coef. = {round(corr[parameter_list[11]],3)}")
    
    plt.xlabel('Experimental ΔΔG (kcal/mol)')
    plt.ylabel('Predicted ΔΔG (kcal/mol)')
       
    #save figure
    plt.savefig("complete_regplot.pdf", bbox_inches="tight")
    
    return


#creation of individual correlation plots
def correlationplots(i, c):
    #define x and y fot plotting
    x = ddG['ddG']
    y = ddG[parameter_list[i]]
    #set figure size
    plt.figure(figsize=(6,6))
    #create basic scatterplot with error bars
    plt.errorbar(x, y, yerr=ddG[parameter_list[i+1]], xerr=ddG['std'], fmt="o", color=c, alpha=0.3)
    m, b = np.polyfit(x, ddG[parameter_list[i]], 1)
    plt.plot(x, corr[parameter_list[i]]*x+b, color = c)
    #add the regression line
    #obtain m (slope) and b(intercept) of linear regression line, 
    m, b = np.polyfit(x, y, 1)
    #add linear regression line to scatterplot 

    #use pearson correficient rather than m
    plt.plot(x, corr[parameter_list[i]]*x+b, color = c, alpha=0.9)
    
    #add the coeficient and axis labels
    #plt.text(0,-2, f"{parameter_list[i]}, Pearson Coeficient: {round(corr[parameter_list[i]],3)}")
    plt.xlabel('Experimental ΔΔG (kcal/mol)')
    plt.ylabel('Predicted ΔΔG (kcal/mol)')
    
    #save figure
    plt.savefig(f"{parameter_list[i]}_regplot.pdf")
    
    return

#run for all the relevant parameters
#for i in [3, 5, 7, 9, 11]:
#    correlationplots(i, c) 

correlationplot_collected()
    
correlationplots(9, 'black')
correlationplots(3, 'orange')
correlationplots(5, 'royalblue')
correlationplots(7, 'blueviolet')
correlationplots(11, 'magenta')


