import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#import the csv
ddG = pd.read_csv('ddG_compare.csv')

#calculate the peason correlations
correlations = ddG.corr(method='pearson')
#extract the correlations with experimental ddG
corr = correlations.iloc[0]

#extract the column names as parameters
parameter_list = list(ddG.columns)


#creation of individual correlation plots
def correlationplots(i):
    #define x and y fot plotting
    x = ddG['ddG']
    y = ddG[parameter_list[i]]
    #set figure size
    plt.figure(figsize=(5,5))
    #create basic scatterplot with error bars
    plt.errorbar(x, y, yerr=ddG[parameter_list[i+1]], xerr=ddG['std'], fmt="o", color='black')
    #add the regression line
    #obtain m (slope) and b(intercept) of linear regression line, 
    m, b = np.polyfit(x, y, 1)
    #add linear regression line to scatterplot 
    #use pearson correficient rather than m
    plt.plot(x, corr[parameter_list[i]]*x+b, color = "grey")
    
    #add the coeficient and axis labels
    plt.text(0.7,-1.3, f"{parameter_list[i]}, Pearson Coeficient: {round(corr[parameter_list[i]],3)}")
    plt.xlabel('Experimental ΔΔG (kcal/mol)')
    plt.ylabel('Predicted ΔΔG (kcal/mol)')
    
    #save figure
    plt.savefig(f"{parameter_list[i]}_regplot.pdf")
    
    return

#run for all the relevant parameters
for i in [3, 5, 7, 9]:
    correlationplots(i) 
    
    
def correlationplot_collected():
    #define x and y fot plotting
    x = ddG['ddG']
    #set figure size
    plt.figure(figsize=(5,5))
    #create basic scatterplot with error bars
    
    #25
    plt.errorbar(x, ddG[parameter_list[3]], yerr=ddG[parameter_list[3+1]], xerr=ddG['std'], fmt="o", color='black')
    m, b = np.polyfit(x, ddG[parameter_list[3]], 1)
    plt.plot(x, corr[parameter_list[3]]*x+b, color = "black")
    
    #50
    plt.errorbar(x, ddG[parameter_list[5]], yerr=ddG[parameter_list[5+1]], xerr=ddG['std'], fmt="o", color='Blue')
    m, b = np.polyfit(x, ddG[parameter_list[5]], 1)
    plt.plot(x, corr[parameter_list[5]]*x+b, color = "blue")
    
    #100
    plt.errorbar(x, ddG[parameter_list[7]], yerr=ddG[parameter_list[7+1]], xerr=ddG['std'], fmt="o", color='red')
    m, b = np.polyfit(x, ddG[parameter_list[7]], 1)
    plt.plot(x, corr[parameter_list[7]]*x+b, color = "red")
    
    #xray
    plt.errorbar(x, ddG[parameter_list[9]], yerr=ddG[parameter_list[9+1]], xerr=ddG['std'], fmt="o", color='yellow')
    m, b = np.polyfit(x, ddG[parameter_list[9]], 1)
    plt.plot(x, corr[parameter_list[9]]*x+b, color = "yellow")
    
    
    plt.xlabel('Experimental ΔΔG (kcal/mol)')
    plt.ylabel('Predicted ΔΔG (kcal/mol)')
       
    #save figure
    plt.savefig("complete_regplot.pdf")
    
    return

correlationplot_collected()
