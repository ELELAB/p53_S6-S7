import pandas as pd
import os
from ddg_extract import doc_names, avg_ddg_mutatex

###############################################################################
#   Prepare the path and file
###############################################################################

#define path
path = os.getcwd()

#import comparison file
exp = pd.read_csv("tableExport_DBD_single.csv")

#Extract relevant columns
exp = exp[['Mutation', 'ddG']]

#reverse ddG value so it is compatible with mutateX results.
exp['ddG'] = exp['ddG']*-1

#include std

def std(exp):
    std = exp.groupby(['Mutation']).std()
    mutations = list(exp.Mutation)
    duplicate_mutations = list(set([x for x in mutations if mutations.count(x) > 1]))
    
    standard_dev = []
    
    for i in range(len(exp)):
        
        if exp.Mutation[i] in duplicate_mutations:
            
            for j in range(len(duplicate_mutations)):
                
                if exp.Mutation[i] == duplicate_mutations[j]:
                    d = exp[exp.Mutation == duplicate_mutations[j]]
                    
                    new_val = sum(d.ddG)/len(d.ddG)
                    exp['ddG'] = exp['ddG'].replace([d.ddG], new_val)
                    
                    standard_deviation = float(std[std.index==duplicate_mutations[j]].ddG)
                    standard_dev.append(standard_deviation)
            
        else:
            standard_dev.append("0")
    
    return standard_dev

standard_dev = std(exp)
exp['std'] = standard_dev  

exp = exp.drop_duplicates() 

###############################################################################
#   Running the collection of data
###############################################################################

documents = doc_names(exp, "A")

os.chdir(path+"/saturation_25/final_averages/")
avg1 = avg_ddg_mutatex(documents)
exp["ddG_25frames"] = avg1[0]
exp["std_25frames"] = avg1[1]

os.chdir(path+"/saturation_50/final_averages/")
avg2 = avg_ddg_mutatex(documents)
exp["ddG_50frames"] = avg2[0]
exp["std_50frames"] = avg2[1]

os.chdir(path+"/saturation_100/final_averages/")
avg3 = avg_ddg_mutatex(documents)
exp["ddG_100frames"] = avg3[0]
exp["std_100frames"] = avg3[1]

os.chdir(path+"/saturation_1/final_averages/")
avg4 = avg_ddg_mutatex(documents)
exp["ddG_1frame"] = avg4[0]
exp["std_1frame"] = avg4[1]

os.chdir(path+"/xray/final_averages/")
avg5 = avg_ddg_mutatex(documents)
exp["ddG_Xray"] = avg5[0]
exp["std_xray"] = avg5[1]

os.chdir(path)
exp.to_csv("ddG_compare.csv", index=False)




