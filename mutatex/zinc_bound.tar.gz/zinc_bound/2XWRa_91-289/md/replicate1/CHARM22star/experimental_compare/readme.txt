#MutateX rebuttal case study

#this dir, "experimental_compare" contiains three directories each containing 
#a symbolic link to the respective mutateX runs: 
    
cd saturation_25
ln -s /data/user/shared_projects/p53_jmb_2021/mutatex/zinc_bound/2XWRa_91-289/md/replicate1/CHARMM22star/saturation_25/results/mutation_ddgs/final_averages/ final_averages
cd ..

cd saturation_50
ln -s /data/user/shared_projects/p53_jmb_2021/mutatex/zinc_bound/2XWRa_91-289/md/replicate1/CHARMM22star/saturation_50/results/mutation_ddgs/final_averages/ final_averages
cd ..

cd saturation_100
#Notice that planB is used below
ln -s /data/user/shared_projects/p53_jmb_2021/mutatex/zinc_bound/2XWRa_91-289/md/replicate1/CHARMM22star/saturation_100_planB/results/mutation_ddgs/final_averages/ final_averages
cd ..

#to analyze this activate python 3
module load python/3.7/modulefile

#this analysis require a file containing experimental data:
cp /data/user/shared_projects/p53_jmb_2021/thermomutDB/tableExport_DBD_single.csv .

#a manually created csv file called time.csv

#format:
    
#frames, hours
#25, 54.14
#50, 103.40
#100, 510

frames, hours
25, 51.14
50, 103.40
100, 510

#and two python scipts with functions
#1) value_extract_mutatex.py
#   A script with two simple functions that find relevant ddG values
#2) mutatex_compare_figures.py
#   A scipt to create illustrations specifically for this. 

#and two scripts to run these functions in this setting
#1) comparison.py 
#   A script that calls the above scrips and collects the relevant information. 
#2) time_compare.py
#   A script that import the time csv file, calls the figure function and outputs a figure. 

#To run
python3 comparison.py
python3 time_compare.py

#Output: 
#    1) ddG_compare.csv, a csv file containing the ddGs of the experimental and predictive runs
#    2) timing_barchart.pdf, a barplot compaing time per frame
#    3) performance_regplot.pdf, a regressionplot comparing the performance of the runs. 

