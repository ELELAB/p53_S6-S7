import pandas as pd
from mutatex_compare_figures import time_figure

#import time file
time = pd.read_csv("time.csv")

time_figure(time)
