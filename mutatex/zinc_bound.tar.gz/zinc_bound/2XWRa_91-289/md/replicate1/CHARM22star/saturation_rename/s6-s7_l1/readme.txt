#we here calculate the heatmap for only the residues in the loop S6-S7 and loop L1 included in the file poslist.txt

./run_mutatex_analysis_MD.sh 2XWRa_91-289 md replicate1 CHARMM22star 20_frames_rename_model0_checked.pdb
