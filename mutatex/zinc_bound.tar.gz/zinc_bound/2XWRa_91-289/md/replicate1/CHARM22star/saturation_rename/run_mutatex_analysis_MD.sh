variant=$1
source=$2
replicate=$3
ffield=$4
pdb=$5
. /usr/local/envs/mutatex/bin/activate
#have the list of mutations from thermomutDB and cancermuts
#ln -s ../../../../../../../mutatex/zinc_bound/$variant/$source/$replicate/$ffield/saturation_rename/results/mutation_ddgs/final_averages
#ln -s ../../../../../../../mutatex/zinc_bound/$variant/$source/$replicate/$ffield/saturation_rename/$pdb
#ln -s ../../../../../../../mutatex/zinc_bound/$variant/$source/$replicate/$ffield/saturation_rename/mutation_list.txt


declare -a StringArray1=("thermomutdb_single_DBD_unique.txt" "cancermuts_list.txt" "somatic_p53DB_list.txt" "germline_p53DBD_list.txt" "germline_p53DBD_list.txt" "gnomAD_low_freq.txt")

i=0
for list in ${StringArray1[@]}; do
        i=$((i+1))
        ddg2summary -p $pdb -d final_averages -l mutation_list.txt -L $list
        mv summary.txt summary_$i.txt
done

ddg2excel -p $pdb -d final_averages/ -l mutation_list.txt
ddg2density -p $pdb -d final_averages/ -l mutation_list.txt
ddg2heatmap -p $pdb -d final_averages/ -l mutation_list.txt -x 5 -c viridis -s 40 -f 8
ddg2distribution -p $pdb -d final_averages/ -l  mutation_list.txt -T scatter -u 20 
ddg2logo -p $pdb -d final_averages/ -l  mutation_list.txt -T 1.2 -x 10 -s 40 -f 8 

