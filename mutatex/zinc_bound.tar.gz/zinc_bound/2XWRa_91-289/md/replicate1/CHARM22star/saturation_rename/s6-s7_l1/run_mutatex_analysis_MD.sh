variant=$1
source=$2
replicate=$3
ffield=$4
pdb=$5
. /usr/local/envs/mutatex/bin/activate

ddg2heatmap -p ../$5 -d ../final_averages/ -l ../mutation_list.txt -x 5 -c viridis -s 40 -f 10 -q poslist.txt -o 0_heatmap_vmax5
ddg2heatmap -p ../$5 -d ../final_averages/ -l ../mutation_list.txt -x 5 -n -2.111 -c viridis -s 40 -f 10 -q poslist.txt -o 0_heatmap_vmax5_vmin2
