#analyses of mutatex scan

#Requirements
#mutation lists of interest
- thermomutdb_single_DBD_unique.txt
-  cancermuts_list.txt

./run_mutatex_analysis.sh $variant $source $run $pdb 

#example - for an ensemble use the first structure as reference pdb for analyses
variant=2XWRa_91-289
source=md
replicate=replicate1
ffield=CHARMM22star
pdb=20_frames_rename.pdb

./run_mutatex_analysis_MD.sh 2XWRa_91-289 md replicate1 CHARMM22star 20_frames_rename.pdb

