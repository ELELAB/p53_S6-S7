#heatmap allosigma

#Requirements
- output from allosigma_classify
- allosigma_heatmap

#source python env.
. /usr/local/envs/py37/bin/activate

#symbolic link to output of the first step (i.e. mutations2allosigma)

ln -s ../1.allosigma_classify/allosigma_mut.txt

#symbolic link to output from allosigma
ln -s ../../allosteric_signalling_map/IJUTYXWG.zip

#run heatmap
./allosigma-heatmap -r '207-213' -x 10 -y 33  -f 6 IJUTYXWG.zip allosigma_mut.txt -t
