#mutations2allosigma
#to match the mutation to the UP or DOWN model of allosigma
#NA is used in cases of mutations that cannot be modelled due to small changes in size

#source python env.
. /usr/local/envs/py37/bin/activate
#Requirements
- allosigma-classify
- aminoacids.dat with volume value of aminoacid (Ang^3)
- muts.dat with your mutation list one letter code, i.e. A119G

#the muts.dat in this case is a copy of  selected_neutral_list.txt from ../selected_neutral/

#we set as a minimum difference in volume 5 Ang.^3 in this case 
 ./allosigma-classify  -o allosigma_mut.txt -c 5 muts.dat aminoacids.dat
