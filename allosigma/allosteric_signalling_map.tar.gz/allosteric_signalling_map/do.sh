. /usr/local/envs/py37/bin/activate

../../allosigma-heatmap -r '100-130' -x 20 -y 60 -f 5 IJUTYXWG.zip allosigma_mut.tsv
