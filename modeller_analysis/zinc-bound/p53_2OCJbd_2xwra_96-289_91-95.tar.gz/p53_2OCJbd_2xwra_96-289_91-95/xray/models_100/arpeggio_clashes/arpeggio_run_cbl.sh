# installs docker image - to be run only once, but doesn't hurt to leave it here
docker pull harryjubb/arpeggio

#variables
pdbfile=$1

#NB PDB file needs to be in the same directory where to run

#arpeggio analyses
DOCKER="docker run --rm -v "$(pwd)":/run -u `id -u`:`id -g` -it harryjubb/arpeggio"
$DOCKER python arpeggio.py /run/$pdbfile 

