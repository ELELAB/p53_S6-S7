#
#  Copyright (C) 2021 Simone Scrima <simonescrima@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import pandas as pd 
import os


def count_clash(df):

    df = df[["VdWClash"]]
    count = df.isin([1]).sum().to_string(header=None, 
                                         index=None)
    return(str(count))


def residue_clash(df):

    df = df[["RES1","RES2","VdWClash"]]
    df = df.loc[df['VdWClash'] == 1]
    df = df.sort_values(by=["RES1","RES2"]) 
    return(df)

if __name__ == '__main__':
    arpeggio_contact_list = sys.argv[1]
    with open( arpeggio_contact_list) as f:
        with open('ranking_VdW_clash.csv','w') as w:
            w.write('filename,clash'+'\n')
            l = []
            for line in f:
                contact_file = line.rstrip()
                contact_name = os.path.basename(contact_file)

                df = pd.read_csv(contact_file,
                	             sep = '\t',
                	             names=["RES1",
                	                    "RES2",
            	                        "Clash",
            	                        "Covalent",
            	                        "VdWClash",
            	                        "Vdw",
            	                        "Proximal",
            	                        "Hydrogen-Bond",
                                        "Weak Hydrogen Bond",
                                        "Halogen Bond",
                                        "Ionic",
                                        "Metal Complex",
                                        "Aromatic", 
                                        "Hydrophobic",
                                        "Carbonyl",
                                        "Polar",
                                        "Weak Polar",
                                        "CLASS"])
                count_clash(df)
                print(residue_clash(df))
                w.write(contact_name+ count_clash(df)+'\n')
