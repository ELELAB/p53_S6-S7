#selection of models of the dimer of p53 DBD with reconstructed N-terminal 

1. RANKING

To reproduce the ranking run the bash script ranking.sh

./ranking.sh

The script requires MDAnalysis version 2.0 so before running it activate the virtual environment MDanalysis_v2
The script performs the selection of the model using the script filtering.py 
The script takes in input the list of pdb models from MODELLER and the reference X-ray structure of p53 DBD (2XWR)
For each model the script:

-aligns each monomer (chain B and D)  of the model to chain A of the reference xray structure (2XWR) using backbone atoms of residues 100-286
-calculates for each monomer (chain B and D) of the model the RMSD to chain A of the reference xray structure (2XWR) using the backbone atoms of the reconstruted N-terminal tail, residues 91-96
-calculates for each monomer (chain B and D) the distances used as restraints in MODELLER
-remove from the ranking the models that have distances that change more than +/- 0.5 Å respect to the distance measured in the chain A of the reference x-ray structure (2XWR)
-ranks the models based on the RMSD of the N-terminal tails of both monomers equally weighting them (i.e. the script ranks as "best" the models that have lowest values of RMSD on both the chains)
-The script gives in output a csv file including all the values (RMSD_distances.csv) and a csv file including the ranked models and their RMSD values (ranking_RMSD.csv)

2. ARPEGGIO CLASHES

We copied the top 5 ranked models in the arpeggio_clashes directory and checked them using Arpeggio calculating the VdW clash score 

cd arpeggio_clashes/

bash arpeggio_run_cbl.sh p53_2OCJbd_2xwra_91-289.B999900*/*.pdb (to run for each pdb in the respective folder)
find -name '*.contacts' | cut -c3- > list_contacts.txt
python analyze_arpeggio.py list_contacts.txt

NB. remove the files that are not .contacts within the arpeggio folders

The dataframe "ranking_VdW_clash.csv" contains the clash score for each model.

----------------------------------------------------------------------------------------------

Ultimately, we selected based on previosly calculated scores and visual inspection using PyMol

p53_2OCJbd_2xwra_91-289.B99990009.pdb
