mkdir ranking
source scripts/MDanalysis_v2/bin/activate
cd ranking
ls ../../../../../modeller/zinc_bound/p53_2OCJbd_2xwra_96-289_91-95/pdb_redo/models_100/models/p53_2OCJbd_2xwra_91-289.B99990* > list_models.txt
cp ../scripts/filtering.py .
cp ../../../../../modeller/zinc_bound/p53_2OCJbd_2xwra_96-289_91-95/pdb_redo/models_100/2XWR_clean_A.pdb .
python filtering.py list_models.txt 2XWR_clean_A.pdb

