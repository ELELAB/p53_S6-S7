#
#     Copyright (C) 2021 
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import sys
import pandas as pd
#from modeller import *
#from modeller.scripts import complete_pdb
import MDAnalysis as mda
from MDAnalysis.analysis import distances
from MDAnalysis.analysis import rms
from MDAnalysis.analysis import align
import numpy as np

def reorder_selection(sel1,
                      sel2):

    # Reorder selection one based on 
    # atom types of selection two
    if len(sel1) != len(sel2):
        quit()
    else:

        selection = []
        for i in range(len(sel2.names)):
            resid = str(sel2.resids[i])
            tipe = sel2.names[i]
            selection.append(sel1.select_atoms("name "+ tipe+ " and resid "+ resid))
        sel1 = sum(selection)
    return(sel1)



if __name__ == '__main__':
    pdbs_list = sys.argv[1]
    pdb_ref = sys.argv[2]

    # create Universe
    u_ref = mda.Universe(pdb_ref)
    with open(pdbs_list) as f:
        l = []
        for line in f:
            # Select the models
            pdb = line.rstrip()
            print(pdb)
            u_models = mda.Universe(pdb)
            
            #align chain A of the models to chain A of the reference xray structure
            u_models_1 = u_models.select_atoms('name CA and (resid 100-286) and chainID A')
            u_ref_1 = u_ref.select_atoms('name CA and (resid 100-286) and chainID A')
            align.alignto(u_models_1,
                                  u_ref_1,
                                  match_atoms=True) # match atoms type
            # calculate RMSD on the N-term tail of chain A of the models that has been reconstructed with MODELLER
            u_models_1nterm = u_models.select_atoms('(((name CA or name CB or name CG or name O or name N or name C) and resid 91-96) or ((name CH2 or name NE1 or name CZ2) and resid 91) or (name OG and resid 94)) and chainID A')
            u_ref_1nterm = u_ref.select_atoms('(((name CA or name CB or name CG or name O or name N or name C) and resid 91-96) or ((name CH2 or name NE1 or name CZ2) and resid 91) or (name OG and resid 94)) and chainID A')
            u_ref_1nterm = reorder_selection(u_ref_1nterm,u_models_1nterm)
            rmsd_tail1 = rms.rmsd(u_models_1nterm.positions,u_ref_1nterm.positions)



            #align chain B of the models to chain A of the reference xray structure
            u_models_2 = u_models.select_atoms('name CA and (resid 100-286) and chainID B')
            u_ref_2 = u_ref.select_atoms('name CA and (resid 100-286) and chainID A')
            align.alignto(u_models_2,
                                  u_ref_2,
                                  match_atoms=True) # match atoms type
            # calculate RMSD on the N-term tail of chain B of the models that has been reconstructed with MODELLER
            u_models_2nterm = u_models.select_atoms('(((name CA or name CB or name CG or name O or name N or name C) and resid 91-96) or ((name CH2 or name NE1 or name CZ2) and resid 91) or (name OG and resid 94)) and chainID B')
            u_ref_2nterm = u_ref.select_atoms('(((name CA or name CB or name CG or name O or name N or name C) and resid 91-96) or ((name CH2 or name NE1 or name CZ2) and resid 91) or (name OG and resid 94)) and chainID A')
            u_ref_2nterm = reorder_selection(u_ref_2nterm,u_models_2nterm)
            rmsd_tail2 = rms.rmsd(u_models_2nterm.positions,u_ref_2nterm.positions)
            
            # calculate distances in chainA used as restraints in MODELLER
            arg174_cz_a = u_models.select_atoms("name CZ and resid 174 and chainID A")
            trp91_cg_a = u_models.select_atoms("name CG and resid 91 and chainID A")
            d1 = distances.dist(arg174_cz_a, trp91_cg_a)
            arg174_cz_a = u_models.select_atoms("name CZ and resid 174 and chainID A")
            trp91_ch2_a = u_models.select_atoms("name CH2 and resid 91 and chainID A")
            d2 = distances.dist(arg174_cz_a, trp91_ch2_a)
            thr211_o_a = u_models.select_atoms("name O and resid 211 and chainID A")
            ser94_og_a = u_models.select_atoms("name OG and resid 94 and chainID A")
            d3 = distances.dist(thr211_o_a, ser94_og_a)
            ser94_og_a = u_models.select_atoms("name OG and resid 94 and chainID A")
            ser96_n_a = u_models.select_atoms("name N and resid 96 and chainID A")
            d4 = distances.dist(ser94_og_a, ser96_n_a)
            thr170_o_a = u_models.select_atoms("name O and resid 170 and chainID A")
            ser94_n_a = u_models.select_atoms("name N and resid 94 and chainID A")
            d5 = distances.dist(thr170_o_a, ser94_n_a)
            pro92_cb_a = u_models.select_atoms("name CB and resid 92 and chainID A")
            phe212_cg_a = u_models.select_atoms("name CG and resid 212 and chainID A")
            d6 = distances.dist(pro92_cb_a, phe212_cg_a)


            # calculate distances in chainB used as restraints in MODELLER
            arg174_cz_b = u_models.select_atoms("name CZ and resid 174 and chainID B")
            trp91_cg_b = u_models.select_atoms("name CG and resid 91 and chainID B")
            d7 = distances.dist(arg174_cz_b, trp91_cg_b)
            arg174_cz_b = u_models.select_atoms("name CZ and resid 174 and chainID B")
            trp91_ch2_b = u_models.select_atoms("name CH2 and resid 91 and chainID B")
            d8 = distances.dist(arg174_cz_b, trp91_ch2_b)
            thr211_o_b = u_models.select_atoms("name O and resid 211 and chainID B")
            ser94_og_b = u_models.select_atoms("name OG and resid 94 and chainID B")
            d9 = distances.dist(thr211_o_b, ser94_og_b)
            ser94_og_b = u_models.select_atoms("name OG and resid 94 and chainID B")
            ser96_n_b = u_models.select_atoms("name N and resid 96 and chainID B")
            d10 = distances.dist(ser94_og_b, ser96_n_b)
            thr170_o_b = u_models.select_atoms("name O and resid 170 and chainID B")
            ser94_n_b = u_models.select_atoms("name N and resid 94 and chainID B")
            d11 = distances.dist(thr170_o_b, ser94_n_b)
            pro92_cb_b = u_models.select_atoms("name CB and resid 92 and chainID B")
            phe212_cg_b = u_models.select_atoms("name CG and resid 212 and chainID B")
            d12 = distances.dist(pro92_cb_b, phe212_cg_b)
            
            l.append([pdb,rmsd_tail1,rmsd_tail2,d1[2][0],d2[2][0],d3[2][0],d4[2][0],d5[2][0],d6[2][0],
                      d7[2][0],d8[2][0],d9[2][0],d10[2][0],d11[2][0],d12[2][0]])            

df = pd.DataFrame(l,columns=['Model ID',
                             'RMSD chain A (Å)',
                             'RMSD chain B (Å)',
                             'dist R174-CZ W91-CG ch.A (Å)',
                             'dist R174-CZ W91-CH2 ch.A (Å)',
                             'dist T211-O S94-OG ch.A (Å)',
                             'dist S94-OG S96-N ch.A (Å)',
                             'dist T170-O S94-N ch.A (Å)',
                             'dist P92-CB F212-CG ch.A (Å)',
                             'dist R174-CZ W91-CG ch.B (Å)',
                             'dist R174-CZ W91-CH2 ch.B (Å)',
                             'dist T211-O S94-OG ch.B (Å)',
                             'dist S94-OG S96-N ch.B (Å)',
                             'dist T170-O S94-N ch.B (Å)',
                             'dist P92-CB F212-CG ch.B (Å)'])

#remove outliers +/- 0.5 Å respect to the distance measured in the reference x-ray structure
df = df.drop(df[(df['dist R174-CZ W91-CG ch.A (Å)'] > 4.5)|(df['dist R174-CZ W91-CG ch.A (Å)'] < 3.5)].index)
df = df.drop(df[(df['dist R174-CZ W91-CH2 ch.A (Å)'] > 4.8)|(df['dist R174-CZ W91-CH2 ch.A (Å)'] < 3.8)].index)
df = df.drop(df[(df['dist T211-O S94-OG ch.A (Å)'] > 3.2)|(df['dist T211-O S94-OG ch.A (Å)'] < 2.2)].index)
df = df.drop(df[(df['dist S94-OG S96-N ch.A (Å)'] > 3.8)|(df['dist S94-OG S96-N ch.A (Å)'] < 2.8)].index)
df = df.drop(df[(df['dist T170-O S94-N ch.A (Å)'] > 3.3)|(df['dist T170-O S94-N ch.A (Å)'] < 2.3)].index)
df = df.drop(df[(df['dist P92-CB F212-CG ch.A (Å)'] > 5.5)|(df['dist P92-CB F212-CG ch.A (Å)'] < 4.5)].index)
df = df.drop(df[(df['dist R174-CZ W91-CG ch.B (Å)'] > 4.5)|(df['dist R174-CZ W91-CG ch.B (Å)'] < 3.5)].index)
df = df.drop(df[(df['dist R174-CZ W91-CH2 ch.B (Å)'] > 4.8)|(df['dist R174-CZ W91-CH2 ch.B (Å)'] < 3.8)].index)
df = df.drop(df[(df['dist T211-O S94-OG ch.B (Å)'] > 3.2)|(df['dist T211-O S94-OG ch.B (Å)'] < 2.2)].index)
df = df.drop(df[(df['dist S94-OG S96-N ch.B (Å)'] > 3.8)|(df['dist S94-OG S96-N ch.B (Å)'] < 2.8)].index)
df = df.drop(df[(df['dist T170-O S94-N ch.B (Å)'] > 3.3)|(df['dist T170-O S94-N ch.B (Å)'] < 2.3)].index)
df = df.drop(df[(df['dist P92-CB F212-CG ch.B (Å)'] > 5.5)|(df['dist P92-CB F212-CG ch.B (Å)'] < 4.5)].index)
col1 = df["RMSD chain A (Å)"]
col2 = df["RMSD chain B (Å)"]
df['Rank'] = (col1+col2).rank(method='dense', ascending=True).astype(int)
df = df.sort_values(['Rank'],ascending = (True))
df.to_csv('RMSD_distances.csv', index = False)
print(df)
header = ["Model ID", "RMSD chain A (Å)", "RMSD chain B (Å)", "Rank"]
df.to_csv('ranking_RMSD.csv', columns = header)
print(df)
