mkdir ranking
source MDanalysis_v2/bin/activate
cd ranking
ls /data/raw_data/computational_data/modeller_data/tcga_3d/p53/zinc_bound/p53_3KZ8bcd_2xwra_95-292_91_95/xray/models_100/models/p53_3KZ8_DNA_BCD_2xwra_91-289.B99990* > list_models.txt
cp ../scripts/filtering.py .

cp /data/raw_data/computational_data/modeller_data/tcga_3d/p53/zinc_bound/p53_3KZ8bcd_2xwra_95-292_91_95/xray/models_100/2XWR_clean_A.pdb .
python filtering.py list_models.txt 2XWR_clean_A.pdb
